<?php
$host="localhost";
$user="root";
$pass="";
$db="gym_dbs";

mysql_connect($host,$user,$pass);
mysql_select_db($db);
if (isset($_POST['email']))
{
	$username=$_POST['email'];
	$password=$_POST['password'];
	$sql="SELECT * FROM member WHERE email_address='".$username."' AND confpass='".$password."'";
	$res=mysql_query($sql);
	if (mysql_num_rows($res)==1){
		echo "You have succesfully logged in.";
		exit();
	}else{
		echo"Invalid login information.";
		exit();
	}

}
?>
