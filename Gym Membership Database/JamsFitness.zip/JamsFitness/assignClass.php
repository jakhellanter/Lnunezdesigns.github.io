<?php
  require_once('config.php');
  //phpinfo();
?>

<!DOCTYPE html>
<html>
	
<head>
	<title>Admin</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
</head>
<?php
      $username = "database-username";
      $password = "database-password";
      $host = "localhost";
      $result = $con->query("SELECT *FROM trainer");
?>
<body>
<nav class="navbar navbar-default" style="position: absolute; height: 100%; background-color:#334d4d; color: white !important;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="activitylog.php">JamsFitnessGYM</a>  
    </div>
    <br>
    <br>
    <ul class="nav nav-pills nav-stacked">
      <li><a href="activitylog.php>">Activity log</a></li>
      <li><a href="register1.php">Register</a></li>
      <li><a href="delete.php">Delete</a></li>
      <li><a href="active.php">Activate</a></li>
      <li class="active"><a href="assingClass.php">Assign Class</a></li>
    </ul>
  </div>
</nav>

<div style="position: absolute; left: 13%; width: 87%; height: 100%;background-color: white; overflow: auto;">
  <div style="position: absolute; left: 0%; width: 100%; height: 70%;background-color: white; overflow: auto;">
   <div class="container" style="position: absolute; overflow: auto;">      
      <form method="POST">
        <h2>Input Trainor</h2>
        <input type="text" name="search" placeholder="Search..">
        <?php
            if(isset($_POST['search'])){

              while( $row = mysqli_fetch_array($result,MYSQLI_ASSOC) ){?>
                <br>
                <br>
                <br>
                  <div class="container">
                    <div class="panel panel-success" style="width: 30%;">
                      <div class="panel-heading">Trainer Name:</div>
                      <div class="panel-body"><?php echo $row['trainer_name'];?></div>
                    </div>
                    <div class="group-group">
                    <label>Class Type:
                    <select class="form-control" name ="classtype">
                      <option disabled selected value="">Please select user type</option>
                      <?php echo "<option value=$var1>Boxing</option>"?>
                      <?php echo "<option value=$var2>Zumba</option>"?>
                      <?php echo "<option value=$var3>Strenght</option>"?>
                    </select>
                    </label>
                </div>
                  </div>
                
        <?php    };
          }
         ?>
      </form>                                                                                       
    </div>
  </div>
</div>

</div>        

</body>
<style> 
input[type=text] {
    width: 130px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url("Images/searchicon.png");
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
    width: 100%;
}
</style>
</html>