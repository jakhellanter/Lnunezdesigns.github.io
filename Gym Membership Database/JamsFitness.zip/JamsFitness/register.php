<?php
header('location: register.html');
define('HOSTNAME','localhost');
define('DBNAME','gym_dbs');
define('USERNAME','root');
define('PASSWORD','');

$connect = new mysqli(HOSTNAME,USERNAME,PASSWORD,DBNAME);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
} 

if($_POST){
$firstname = $_POST['fname'];
$lastname= $_POST['lname'];
$age = $_POST['age'];
$address = $_POST['address'];
$contact= $_POST['contact_no'];
$bmi = $_POST['bmi'];
$medrec = $_POST['med_records'];
$email= $_POST['email'];
$password = $_POST['password'];
$usertype= $_POST['usertype'];
$datecreated=date("Y/m/d");
$expirydate=date('Y-m-d H:i', strtotime($_POST['date_exp']));
$timein=$_POST['time_in'];
$timeout=$_POST['time_out'];




$connect->query("INSERT INTO member(
	fname,lname,address,contact_no,bmi,med_records,email_address,confpass,age,date_created,expiry_date,time_in,time_out) 
	VALUES ('$firstname','$lastname','$address','$contact','$bmi','$medrec','$email','$password','$age','$datecreated','$expirydate','$timein','$timeout')");
$connect->close();
}

?>