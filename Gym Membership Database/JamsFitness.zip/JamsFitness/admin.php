<?php
header('location: activitylog.php');
if(isset($_POST['name']))
{
	date_default_timezone_set("America/New_York");
	$con=mysqli_connect("localhost","root","") or die("cannot connect to database");
	mysqli_select_db($con,"gym_dbs") or die("cannot connect to database");
	$query="INSERT INTO walk_in(name,time_in) VALUES ('".$_POST['name']."', '".date('Y-m-d h:i:s')."')";
	mysqli_query($con,$query) or die ("error");


}
?>
