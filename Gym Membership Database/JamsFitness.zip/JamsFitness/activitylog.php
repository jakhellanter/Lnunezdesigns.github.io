<?php
  require_once('config.php');
  //phpinfo();
?>

<!DOCTYPE html>
<html>
	
<head>
	<title>Admin</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
</head>
<?php
      $username = "database-username";
      $password = "database-password";
      $host = "localhost";
      $result = $con->query("SELECT *FROM walk_in WHERE time_in IS NOT NULL ORDER BY walk_in_id DESC");
?>
<body>
<nav class="navbar navbar-default" style="position: absolute; height: 100%; background-color:#334d4d; color: white !important;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="activitylog.php">JamsFitnessGYM</a>  
    </div>
    <br>
    <br>
    <ul class="nav nav-pills nav-stacked">
      <li class="active"><a href="#">Activity log</a></li>
      <li><a href="register1.php">Register</a></li>
      <li><a href="delete.php">Delete</a></li>
      <li><a href="active.php">Activate</a></li>
    </ul>
  </div>
</nav>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Walk In</h4>
        </div>
        <form method="POST" action="admin.php">
          <div class="form-group">
  			<label for="usr">Name:</label>
  				<input type="text" class="form-control" name="name">
        </div>
        <div class="group-group">
            <label>User Type:
            <select class="form-control" name ="usertype"required>
              <option disabled selected value="">Please select user type</option>
              <option value="member">Member</option>
              <option value="trainor">Trainor</option>
            </select>
            </label>
        </div>
        <div class="modal-footer">
        <div>
          <button type="submit" class="btn btn-default" href="#">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </form>
        </div>
      </div>
      
    </div>
  </div>
 </div>
<!--
 <div class="modal fade" id="myymodaL" role="dialog">
    <div class="modal-dialog">
    
      
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Member</h4>
        </div>
        <form method="post" action="login.php">
          <div class="form-group">
  			<label for="usr">Email:</label>
  				<input type="text" class="form-control" id="email" name="Email">
		  </div>
		  <div class="form-group">
  		  	<label for="pwd">Password:</label>
  		  	<input type="password" class="form-control" id="pwd">
		  </div>
        <div class="modal-footer">
        <div>
          <button type="submit" class="btn btn-default">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
     	</form>
    </div>
  </div>
</div>
-->
<div style="position: absolute; left: 13%; width: 87%; height: 100%;background-color: white; overflow: auto;">
  <div style="position: absolute; left: 0%; width: 100%; height: 70%;background-color: white; overflow: auto;">
   <div class="container" style="position: absolute; overflow: auto;">                                                                                               
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Date - Time In</th>
      </thead>
      <tbody>
        <?php
          //if(mysqli_num_rows($result)>0)
            //{
            //$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
              while( $row = mysqli_fetch_array($result,MYSQLI_ASSOC) ){
              echo 
              "<tr>
                <td>{$row['walk_in_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['time_in']}</td>
              </tr>";
            }
          //}
        ?>

      </tbody>
    </table>
    </div>
  </div>
</div>
<!--<form method="POST" action="admin1.php"></form>-->

   
</div>        


<div class="buttons" style="position: absolute; left:45%; top: 80%;">
    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">Log In</button>
    <!--<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myymodaL">Member</button>-->
  </div>
</body>

</html>