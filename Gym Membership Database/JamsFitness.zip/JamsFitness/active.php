<?php
  require_once('config.php');
  //phpinfo();
?>
<!DOCTYPE html>
<html>
	
<head>
	<title>Admin</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="adminstyle.css">
	<script src="js/jquery/3.2.1/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</head>
<?php
      $username = "database-username";
      $password = "database-password";
      $host = "localhost";
      //$walk_ind= $_POST['res'];
      //$query = "select id, name from walk_in "; 
      $result = $con->query("SELECT * FROM member ");
?>

<nav class="navbar navbar-default" style="position: absolute; height: 100%; background-color:#334d4d; color: white !important;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">JamsFitnessGYM</a>
    </div>
    <br>
    <br>
    <ul class="nav nav-pills nav-stacked">
      <li><a href="activitylog.php">Activity log</a></li>
      <li><a href="register1.php">Register</a></li>
      <li><a href="delete.php">Delete</a></li>
      <li class="active"><a href="active.php">Activate</a></li>
    </ul>
  </div>
</nav>
<div style="position: absolute; left: 13%; width: 87%; height: 100%;background-color: white; overflow: auto;">
    <div class="form" style="position: absolute; left: 0%; width: 100%; height: 100%;background-color: white; border-radius: 15px 15px 15px 15px;  overflow: auto;">
      <form method="POST" action="active1.php">
     <div class="container" style="position: absolute; ">                                                                                      
      <div class="table-responsive" style="width: 70%;">          
      <table id="table" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email Address</th>
        </thead>
        <tbody>
          <?php
                while( $row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                $var1 = $row['member_id'] ; 
                if($row['status']=='1'){

                }else{ ?>
                <tr>
                  <td><?php echo "<input type=hidden name=id value =$var1; " ?></td>
                  <td><?php echo $row['fname']; ?></td>
                  <td><?php echo $row['lname']; ?></td>
                  <td><?php echo $row['email_address']; ?></td>
                  <td><button type="submit" class="btn btn-danger" >Activate</button></td>
                </tr>

  <?php
      }
  } 
  ?>      
        </tbody>
      </table>
      </div>
    </div>
    </form>
    </div>
</div>

</body>
</html>