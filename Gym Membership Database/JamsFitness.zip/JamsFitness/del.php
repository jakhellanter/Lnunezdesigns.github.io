<?php
header('location: delete.php');

if($_POST['id']){
	$status=$_POST['id'];
	$con=mysqli_connect("localhost","root","") or die("cannot connect to database");
	mysqli_select_db($con,"gym_dbs") or die("cannot connect to database");
	$con->query("UPDATE member SET status='0' WHERE member_id = '$status'");
	mysqli_query($con,$query) or die ("error");
	$con->close();
}
?>
