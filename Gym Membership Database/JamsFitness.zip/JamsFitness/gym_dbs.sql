-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2017 at 07:56 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_dbs`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `classes_id` int(11) NOT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `classes_name` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `customer_type` enum('walk','member') NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `bmi` float DEFAULT NULL,
  `med_records` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) NOT NULL,
  `confpass` varchar(50) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `customer_id`, `fname`, `lname`, `address`, `contact_no`, `bmi`, `med_records`, `email_address`, `confpass`, `age`, `date_created`, `expiry_date`, `time_in`, `time_out`) VALUES
(1, NULL, 'allison', 'duro', 'Blk 8 Lot 9 Velpal Phase 2 Minglanilla Cebu', 2147483647, 2, 'NONE', 'duroallison@gmail.com', 'jake', 22, '2017-08-18', '0000-00-00', '00:00:00', '00:00:00'),
(3, NULL, 'john', 'rupert', 'jones', 2147483647, 21, 'hubakon, daling mapiang', 'repurtjohn@gmail.com', 'john', 21, '2017-08-18', '2015-01-01', '11:30:00', '12:30:00'),
(4, NULL, 'luigi', 'nunez', 'lapu-lapu', 912412421, 28, 'none', 'luigi@gmial.com', 'jake', 23, '2017-08-19', '2020-10-10', '01:30:00', '02:30:00'),
(5, NULL, 'renzie', 'duro', 'minglanilla', 1234567, 16, 'na', 'sfsafds', 'jake', 19, '2017-09-15', '2020-10-10', '00:00:00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `program_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `exercise_name` char(20) DEFAULT NULL,
  `no_reps` int(11) DEFAULT NULL,
  `no_sets` int(11) DEFAULT NULL,
  `day_scheduled` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `trainer_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainer_name` char(1) DEFAULT NULL,
  `trainer_age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `walk_in`
--

CREATE TABLE `walk_in` (
  `walk_in_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `name` char(20) DEFAULT NULL,
  `time_in` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `walk_in`
--

INSERT INTO `walk_in` (`walk_in_id`, `customer_id`, `name`, `time_in`) VALUES
(1, NULL, 'allison', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`classes_id`),
  ADD KEY `trainer_classes_fk` (`trainer_id`),
  ADD KEY `member_class_fk` (`member_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `customer_m_pk` (`customer_id`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`program_id`),
  ADD KEY `member_program_fk` (`member_id`);

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`trainer_id`);

--
-- Indexes for table `walk_in`
--
ALTER TABLE `walk_in`
  ADD PRIMARY KEY (`walk_in_id`),
  ADD KEY `customer_pk` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `walk_in`
--
ALTER TABLE `walk_in`
  MODIFY `walk_in_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `member_class_fk` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  ADD CONSTRAINT `trainer_classes_fk` FOREIGN KEY (`trainer_id`) REFERENCES `trainer` (`trainer_id`);

--
-- Constraints for table `member`
--
ALTER TABLE `member`
  ADD CONSTRAINT `customer_m_pk` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `member_program_fk` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`);

--
-- Constraints for table `walk_in`
--
ALTER TABLE `walk_in`
  ADD CONSTRAINT `customer_pk` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
