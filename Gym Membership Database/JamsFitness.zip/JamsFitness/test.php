<?php
  session_start();
  require_once('config.php');
  //phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<script src="jquery/3.2.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<header class="header">
      <ul>
        <li><a id="login" href="#">Login</a></li>
        <li><a href="#section4">Announcements</a></li>
        <li><a href="#section3">Gallery</a></li>
        <li><a href="#section2">Learn More</a></li>
        <li><a href="#section1">Home</a></li>
        <div class="logo"><img src="Images/logo.jpg" width="200" height="67"></div>
      </ul> 
</header>

<div id="myModal" class="modal">

  
    <form method="POST" action="test.php " class="form-horizontal" role="form">
    <div class="member"><b>Member</div>
    <span class="close">&times;</span>
    <div class="form-group">
    <label for="email">Email address:
    </label>
    <input type="username" class="form-control" name="email">
    </div>
    <div  class="form-group">
    <label for="pwd">Password:
    </label>
    <input type="password" class="form-control" name="password">
    </div>
    <div class="form-group">
    <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
    </div>
    </div>
    <button type="submit" class="btn btn-default" name="login" >Submit</button>
    </form>
    <?php
      if(isset($_POST['login']))
      {
        $username=$_POST['email'];
        $password=$_POST['password'];
        if($username=="admin" && $password=="admin"){
          require_once('admin.php');
        }else{
        $query = "select * from member where email_address='$username' and confpass='$password' ";
        //echo $query;
        $query_run = mysqli_query($con,$query);
        //echo mysql_num_rows($query_run);
        if($query_run)
        {
          if(mysqli_num_rows($query_run)>0)
          {
          $row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
          
          $_SESSION['email'] = $username;
          $_SESSION['password'] = $password;
          
          header( "location: userlogin.php");
          }
          else
          {
            echo '<script type="text/javascript">alert("Invalid Email or Password!")</script>';
          }
        }
        else
        {
          echo '<script type="text/javascript">alert("Database Error")</script>';
        }
      }
      //else
     // {
     // }
      }
    ?>
</div>
</head>


<body>

    <div id="section1" class="background">
      <div class="getfit" >Get Fit <b>Today</b>
          <div class="join">Join the #1 Fitness Center in Lapu-Lapu
          Find the Fitness Class that's right for you, or choose a personal training session to get your workout into high
          <a href="#section2" id="ler" class="learn">LEARN MORE
          </a>
      </div>
    </div>
    <div id="section2" class="what">
      <br>
      <br>
      <br>
      <h1>What We Offer</h1>
      <h3 class="sub">Choose the right Fitness class that suit your taste or you can enroll all our class</h3>
      <div class="strenght"><image src="Images/strength_logo.png" width="200" height="200"></div>
      <div class="boxing"><image src="Images/boxing.jpg" width="200" height="200"></div>
      <div class="zumba"><image src="Images/zumba.png" width="150" height="150"></div>
      <div class="body">Body Building</div>
      <div class="boxing1">Boxing</div>
      <div class="zumba1">Zumba</div>
      <div class="bodydes">Body Building, we provide the exact exercise to suit the outcome of the dream body that you wanted, you'll be able to keep track of your progress</div>
      <div class="boxdes">Boxing, an intense boxing workout to sweat and get your body into shape. we can also provide amateur routine</div>
      <div class="zumbades">Zumba, is to let you sweat through dancing, the twist is the zumba is more intense than other zumba class to make you sweat and achieve thinner body through zumba</div>
    </div>
  <div id="section3" class="gallery">
  <div>
    <br>
    <br>
    <br>
    <h2>Sneak Peak of our GYM</h2>
    <div class="slideshow">
    <img class="Myslides" src="Images/weight-room.jpg" style="width:100%">
    <img class="Myslides" src="Images/boxing-gym.jpg" style="width:100%">
    <img class="Myslides" src="Images/gym-lakewood.jpg" style="width:100%">
    </div>
  </div>
  <div id="section4" class="announcements">
    <br>
    <br>
    <br>
    <h4>Announcements</h4>
    <br>
    <br>
    <div class="sub">NO CLASS ON MONDAY</div>

  </div>
</body>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("login");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("Myslides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}

</script>
</html>

