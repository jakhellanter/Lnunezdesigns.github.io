<?php
header('location: delete.php');

	$con=mysqli_connect("localhost","root","") or die("cannot connect to database");
	mysqli_select_db($con,"gym_dbs") or die("cannot connect to database");
	$query="DELETE FROM member;
	mysqli_query($con,$query) or die ("error");

?>
