<?php
 session_start();
  require_once('config.php');
  //phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="userlogin.css">

<script src="jquery/3.2.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

    <!--$walk_ind= $_POST['res'];
      //$query = "select id, name from walk_in "; -->

<header class="header">

      <ul>
        <?php
          //if(mysqli_num_rows($result)>0)
            //{
//WHERE {$_SESSION['email']='$email'
//$email = ($_POST['email']);

            $inputEmail= $_SESSION['email'];

            $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'"); //WHERE $smail='email'
          //  $queried_name = $row['fname'];

              while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){

              echo "<p>Welcome " . $row['fname'] . "</p>";
            }
 //"<li>Welcome {$_SESSION['fname']} </li>"
              //echo "<li>Welcome {$row['fname']}</li>";


//
        ?>

        <div class="logo"><img src="Images/logo.jpg" width="200" height="67"></div>
      </ul>
</header>

</head>


<body>

  <div class="container">
  	<div class="row">
  		<h2>Create your snippet's HTML, CSS and Javascript in the editor tabs</h2>


         <div class="col-md-7 ">

  <div class="panel panel-default">
    <div class="panel-heading" style="background-color:#363435;"><h4 >User Profile</h4></div>
     <div class="panel-body" style="background-color: #d9d9d9 !important;">

      <div class="box box-info">

              <div class="box-body">
                       <div class="col-sm-6">
                       <div  align="center"> <img alt="User Pic" src="https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg" id="profile-image1" class="img-circle img-responsive">

                  <input id="profile-image-upload" class="hidden" type="file">
  <div style="color:#999;" >click here to change profile image</div>
                  <!--Upload Image Js And Css-->
                       </div>

                <br>

                <!-- /input-group -->
              </div>
              <div class="col-sm-6">
                <?php
                $inputEmail= $_SESSION['email'];
                $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");
                    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
                    echo "<h4>" .$row['fname'] ." ". $row['lname'] . "</h4>";
                  ?>
                <span><p><center>Member<center></p></span>
              </div>
              <div class="clearfix"></div>
              <hr style="margin:5px 0 5px 0;">

<!-- FIRST NAME-->
  <div class="col-sm-5 col-xs-6 tital " >First Name:</div><div class="col-sm-7 col-xs-6 ">
<?php
$inputEmail= $_SESSION['email'];

$result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

  echo $row['fname'] ;

  ?>
</div>
       <div class="clearfix"></div>
  <div class="bot-border"></div>

<!-- LAST NAME-->
  <div class="col-sm-5 col-xs-6 tital " >Last Name:</div><div class="col-sm-7">
    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['lname'] ;

      ?>

   </div>
    <div class="clearfix"></div>
  <div class="bot-border"></div>

<!--AGE-->
  <div class="col-sm-5 col-xs-6 tital " >Age:</div><div class="col-sm-7">

    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['age'] ;

      ?>

  </div>
    <div class="clearfix"></div>
  <div class="bot-border"></div>
<!--ADDRESS-->
  <div class="col-sm-5 col-xs-6 tital " >Address:</div><div class="col-sm-7">
    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['address'] ;

      ?>
  </div>
    <div class="clearfix"></div>
  <div class="bot-border"></div>

<!-- JOIN DATE-->
  <div class="col-sm-5 col-xs-6 tital " >Join Date:</div><div class="col-sm-7">
    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['date_created'] ;

      ?>
  </div>
   <div class="clearfix"></div>
  <div class="bot-border"></div>
<!-- EXPIRY DATE-->
  <div class="col-sm-5 col-xs-6 tital " >Expiry Date:</div><div class="col-sm-7">
    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['expiry_date'] ;

      ?>
  </div>

   <div class="clearfix"></div>
  <div class="bot-border"></div>

<!-- CONTACT NO-->
  <div class="col-sm-5 col-xs-6 tital " >Contact Number:</div><div class="col-sm-7">
    <?php
    $inputEmail= $_SESSION['email'];

    $result = $con->query("SELECT * FROM member WHERE email_address='" . $inputEmail. "'");

        while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))

      echo $row['contact_no'] ;

      ?>
  </div>


              <!-- /.box-body -->
            </div>
            <!-- /.box -->

          </div>


      </div>
      </div>
  </div>
      <script>
                $(function() {
      $('#profile-image1').on('click', function() {
          $('#profile-image-upload').click();
      });
  });
                </script>









     </div>
  </div>










</body>

</html>
