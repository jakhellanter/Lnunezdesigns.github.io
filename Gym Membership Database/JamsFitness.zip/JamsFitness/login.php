 <?php
$servername = "localhost";
$username = "email_address";
$password = "root";
$dbname = "gym_dbs";

// Create connection
$conn = new mysqli('localhost' , 'root' , '' , 'gym_dbs');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, email_address, lastname FROM member";
$result = $conn->query($sql);


if ($result == 1) {
$_SESSION['login_user']=$username; // Initializing Session
header("location: admin.html"); // Redirecting To Other Page
} else {
$error = "Username or Password is invalid";
}

$conn->close();
?> 